#pragma once

#include "BSplineCurve.h"
#include <vector>
#include <Eigen/Dense>
using Eigen::Vector3f;
class BSplineCurve;

class BSplineSurface {


public:
    bool interpolate(int numSamples);
    bool approximate(int numSamples, int numCtrlPoints);
    void generateDataPoints();
    void getTriangles(std::vector<Vector3f> &vertices, std::vector<int> &indices, float step);
    inline auto getCtrlPoints() {return ctrlPoints;}

public:
    std::vector<std::vector<Vector3f>>  ctrlPoints;
    std::vector<std::vector<Vector3f>>  dataPoints;
    std::vector<BSplineCurve>           curves;

private:
    // Sampling frequency on two dimensions
    int ns;
    int nc;
};
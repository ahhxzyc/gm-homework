#pragma once

#include <vector>
#include <Eigen/Dense>
using Eigen::Vector3f;


class BSplineCurve {
public:
    // Different application scenarios
    bool build(const std::vector<Vector3f> &ctrlPoints);
    bool interpolate(const std::vector<Vector3f> &dataPoints);
    bool approximate(const std::vector<Vector3f> &dataPoints, int numCtrlPoints);
    
    std::vector<Vector3f> getCurve(float step);
    std::vector<Vector3f> getControlPoints();
    Vector3f getPoint(float t);

private:
    void setKnots();
    float getBasis(int i, int k, float t);

private:
    int m_n;
    int m_k = 3;

    std::vector<float>              mKnots;
    std::vector<float>              mParams;
    std::vector<Vector3f>           mPoints;
};
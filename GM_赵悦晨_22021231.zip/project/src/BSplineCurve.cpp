#include "BSplineCurve.h"

#include <cassert>
#include <iostream>
#include <Eigen/Dense>


//
// Build a curve from a list of control points
//
bool BSplineCurve::build(const std::vector<Vector3f> &ctrlPoints) {
    m_n = ctrlPoints.size() - 1;
    if (m_n + 1 <= m_k - 1) {
        return false;
    }
    mPoints = ctrlPoints;
    setKnots();
    return true;
}

//
// Build a curve from a list of data points using interpolation
//
bool BSplineCurve::interpolate(const std::vector<Vector3f> &dataPoints) {
    m_n = dataPoints.size() - 1;
    if (m_n + 1 <= m_k - 1) {
        return false;
    }
    // Uniform parameters
    for (int i = 0; i <= m_n; i ++ ) {
        mParams.push_back((float)i / m_n);
    }
    mParams[m_n] -= 0.0001; // cheat a little ~
    // Uniform knot vector
    setKnots();
    // Create matrices N & D
    Eigen::MatrixXf N(m_n + 1, m_n + 1);
    Eigen::MatrixXf D(m_n + 1, 3);
    for (int i = 0; i <= m_n; i ++ )
        for (int j = 0; j <= m_n; j ++ )
            N(i, j) = getBasis(j, m_k, mParams[i]);
    for (int i = 0; i <= m_n; i ++ )
        for (int j = 0; j < 3; j ++ )
            D(i, j) = dataPoints[i][j];
    // Solve equation NP=D
    Eigen::MatrixXf P = N.inverse() * D;
    // Write down control points
    for (int i = 0; i <= m_n; i ++ )
        mPoints.push_back(Vector3f(P(i,0), P(i,1), P(i,2)));
    return true;
}

//
// Build a b-spline curve from a list of points using approximation
// using 5 control points by default
//
bool BSplineCurve::approximate(const std::vector<Vector3f> &dataPoints, int numCtrlPoints) {
    int n = dataPoints.size() - 1;
    m_n = numCtrlPoints - 1;
    if (m_n > n)
        return false;
    // Uniform parameters
    for (int i = 0; i <= n; i ++ ) {
        mParams.push_back((float)i / n);
    }
    mParams[n] -= 0.0001; // cheat
    // Uniform knot vector
    setKnots();
    // Create Q_k
    std::vector<Vector3f> qk(n + 1);
    for (int i = 0; i < qk.size(); i ++ ) {
        qk[i] = dataPoints[i] - getBasis(0, m_k, mParams[i]) * dataPoints[0]
                - getBasis(m_n, m_k, mParams[i]) * dataPoints[n];
    }
    // Create matrices N & Q
    Eigen::MatrixXf N(n - 1, m_n - 1);
    Eigen::MatrixXf Q(m_n - 1, 3);
    for (int i = 1; i <= n - 1; i ++ )
        for (int j = 1; j <= m_n - 1; j ++ )
            N(i - 1, j - 1) = getBasis(j, m_k, mParams[i]);
    for (int i = 1; i <= m_n - 1; i ++ ) {
        Vector3f q(0,0,0);
        for (int j = 1; j <= n - 1; j ++ )
            q += qk[j] * getBasis(i, m_k, mParams[j]);
        for (int j = 0; j < 3; j ++ )
            Q(i-1, j) = q[j];
    }
    // Solve equation (N.T * N)P=D
    Eigen::MatrixXf P = (N.transpose() * N).inverse() * Q;
    // Write down control points
    mPoints.push_back(dataPoints[0]);
    for (int i = 0; i < m_n - 1; i ++ )
        mPoints.push_back(Vector3f(P(i,0), P(i,1), P(i,2)));
    mPoints.push_back(dataPoints[n]);
    return true;
}

//
// Get bspline basis function N_i,k(t) through recursion
//
float BSplineCurve::getBasis(int i, int k, float t) {
    if (k == 1) {
        return (t >= mKnots[i] && t < mKnots[i + 1]) ? 1 : 0;
    }
    // A region is disgarded if it's outside the valid region [t_k-1,t_n+1)
    int l   = i;
    int r   = i + k;
    int vl  = m_k - 1;
    int vr  = m_n + 1;
    float f1 = (l >= vr || r - 1 <= vl) ? 0.f : (t - mKnots[i]) / (mKnots[i+k-1] - mKnots[i]);
    float f2 = (l + 1 >= vr || r <= vl) ? 0.f : (mKnots[i+k] - t) / (mKnots[i+k] - mKnots[i+1]);
    // Blend two lower basis functions
    float result = f1 * getBasis(i, k - 1, t) + f2 * getBasis(i + 1, k - 1, t);
    return result;
}

// Set knot vector to a uniform sequence
void BSplineCurve::setKnots() {
    int len = m_n + m_k + 1;
    for (int i = 0; i < m_k; i ++ )             mKnots.push_back(0.f);
    for (int i = m_k; i < m_n + 1; i ++ )       mKnots.push_back((float)(i - m_k + 1) / (m_n - m_k + 2));
    for (int i = m_n + 1; i < len; i ++ )       mKnots.push_back(1.f);
}

std::vector<Vector3f> BSplineCurve::getCurve(float step) {
    std::vector<Vector3f> curve;
    int n = mPoints.size() - 1;
    for (float t = mKnots[m_k - 1]; t < mKnots[m_n + 1]; t += step) {
        curve.push_back(getPoint(t));
    }
    return curve;
}

std::vector<Vector3f> BSplineCurve::getControlPoints() {
    return mPoints;
}

// Get P(t) using DeBoor-Cox algorithm
Vector3f BSplineCurve::getPoint(float t) {
    // Find which segment t belongs to
    int l = 0;
    while (t < mKnots[l] || t >= mKnots[l + 1]) l ++ ;
    // Fill degree 0 points
    std::vector<Vector3f> temp(m_k);
    int offset = l - m_k + 1;
    for (int i = 0; i < m_k; i ++ ) {
        temp[i] = mPoints[offset + i];
    }
    // Roll k-1 times
    for (int deg = 1; deg <= m_k - 1; deg ++ ) {
        for (int i = m_k - 1; i >= deg; i -- ) {
            float ratio = (t - mKnots[offset + i]) / (mKnots[offset + i + m_k - deg] - mKnots[offset + i]);
            temp[i] = ratio * temp[i] + (1 - ratio) * temp[i - 1];
        }
    }
    return temp[m_k - 1];
}
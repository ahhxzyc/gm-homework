#include "TinyEngine.h"
#include "Triangle.h"
#include "BSplineSurface.h"
#include <vector>

// Derive a subclass from the engine
class MyApp : public TinyEngine {
public:
    // Constructor
    MyApp(HINSTANCE hinst, int w, int h) : TinyEngine(hinst, w, h) {}

    // onInit() gets executed before the loop
    void onInit() override {
        BSplineSurface surface;
        surface.approximate(20, 8);
        surface.getTriangles(mVertices, mIndices, 0.02);
        for (int i = 0; i < mIndices.size(); i += 3) {
            Triangle3D tri{mVertices[mIndices[i]], mVertices[mIndices[i+1]], mVertices[mIndices[i+2]]};
            addTriangle(tri);
        }
    }

private:
    std::vector<Vector3f>               mVertices;
    std::vector<int>                    mIndices;
    std::vector<std::vector<Vector3f>>  mPoints;
};

// Main function for Win32 Application
int WinMain(HINSTANCE hinstance,
			HINSTANCE hprevinstance,
			LPSTR lpcmdline,
			int ncmdshow) {
    MyApp app(hinstance, 600, 600);     // Create a window
    app.init();                         // Necessary initializations
    app.mainloop();                     // Enter the main loop where stuff gets shown and mouse/keyboard gets answered
}
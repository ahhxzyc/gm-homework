
#include "BSplineSurface.h"

#ifndef PI
#define PI 3.1415926
#endif


void BSplineSurface::generateDataPoints() {
    dataPoints.resize(ns);
    for (int i = 0; i < ns; i ++ ) {
        float u = (float)i / (ns - 1);
        float azim = 2 * PI * u;   // azimuth on xOz plane
        for (int j = 0; j < ns; j ++ ) {
            float v = (float)j / (ns - 1);
            float zen = PI * v;     // zenith
            float radius = 0.8f + ((float)(rand() % 1000) / 1000.f - 0.5f) * 0.1f;
            Vector3f point(radius * sinf(zen) * cos(azim),
                            radius * cos(zen),
                            radius * sinf(zen) * sin(azim));
            dataPoints[i].push_back(point);
        }
    }
}


//
// Interpolation on a sphere
//
bool BSplineSurface::interpolate(int numSamples) {
    nc = ns = numSamples;
    generateDataPoints();
    for (int i = 0; i < ns; i ++ ) {
        // Build bspline curve on the points sampled
        BSplineCurve curve;
        if(!curve.interpolate(dataPoints[i])) {
            return false;
        }
        ctrlPoints.push_back(curve.getControlPoints());
    }
    // Interpolation on second dimension of ctrlPoints
    for (int i = 0; i < nc; i ++ ) {
        std::vector<Vector3f> points;
        for (int j = 0; j < nc; j ++ ) {
            points.push_back(ctrlPoints[j][i]);
        }
        BSplineCurve curve;
        curve.interpolate(points);
        points = curve.getControlPoints();
        for (int j = 0; j < nc; j ++ ) {
            ctrlPoints[j][i] = points[j];
        }
    }
    return true;
}

//
// Approximation on a sphere
//
bool BSplineSurface::approximate(int numSamples, int numCtrlPoints) {
    ns = numSamples;
    nc = numCtrlPoints;
    generateDataPoints();
    for (int i = 0; i < ns; i ++ ) {
        // Build bspline curve on the points sampled
        BSplineCurve curve;
        if(!curve.approximate(dataPoints[i], nc)) {
            return false;
        }
        ctrlPoints.push_back(curve.getControlPoints());
    }
    // Approximation on second dimension of ctrlPoints
    std::vector<std::vector<Vector3f>> newCtrlPoints(nc);
    for (int i = 0; i < ctrlPoints[0].size(); i ++ ) {
        std::vector<Vector3f> points;
        for (int j = 0; j < ctrlPoints.size(); j ++ ) {
            points.push_back(ctrlPoints[j][i]);
        }
        BSplineCurve curve;
        curve.approximate(points, nc);
        points = curve.getControlPoints();
        for (int j = 0; j < nc; j ++ ) {
            newCtrlPoints[j].push_back(points[j]);
        }
    }
    ctrlPoints = newCtrlPoints;
    return true;
}

void BSplineSurface::getTriangles(std::vector<Vector3f> &vertices, std::vector<int> &indices, float step) {
    vertices.clear();
    indices.clear();

    // Build curves on one dimension
    for (int i = 0; i < nc; i ++ ) {
        BSplineCurve curve;
        curve.build(ctrlPoints[i]);
        curves.push_back(curve);
    }
    
    // Use points on the curves as control points to build curves on the other dimension
    int width = 0;
    int height = 0;
    for (float v = 0.f; v < 1.f; v += step, height ++ ) {
        std::vector<Vector3f> cpoints;
        for (int i = 0; i < nc; i ++ ) {
            cpoints.push_back(curves[i].getPoint(v));
        }
        BSplineCurve curve;
        curve.build(cpoints);
        for (float u = 0.f; u < 1.f; u += step) {
            vertices.push_back(curve.getPoint(u));
        }
    }
    width = vertices.size() / height;

    for (int i = 0; i < width - 1; i ++ ) {
        for (int j = 0; j < height - 1; j ++ ) {
            // Bottom left triangle
            indices.push_back(j * height + i);
            indices.push_back(j * height + i + 1);
            indices.push_back((j + 1) * height + i);
            // Top right triangle
            indices.push_back(j * height + i + 1);
            indices.push_back((j + 1) * height + i + 1);
            indices.push_back((j + 1) * height + i);
        }
    }
}
#pragma once

#include "Triangle.h"
#include "AABB.h"
#include <vector>
#include <Eigen/Dense>
using Eigen::Vector3i;

class TinyEngine;
class HZBuffer;

class OctTreeNode {
public:
    OctTreeNode():
            mBox(), mChildren() {}
public:
    AABB3D              mBox;
    std::vector<int>    mChildren;
    std::vector<int>    mIndices;
};



class OctTree {
public:
    OctTree(AABB3D box, const std::vector<Triangle3D> &objects, TinyEngine *engine) :
            mObjects(objects), m_pEngine(engine) {
        std::vector<int> indices;
        for (int i = 0; i < mObjects.size(); i ++ )
            indices.push_back(i);
        mRoot = build(box, indices);
    }

    void drawOctTree();
    void draw(HZBuffer *p_hzbuffer);

private:
    const std::vector<Triangle3D>   &mObjects;
    std::vector<OctTreeNode>        mNodes;
    int                             mRoot;
    TinyEngine                    *m_pEngine;

    int build(AABB3D box, const std::vector<int> &indices);
    
    inline int newNode()        {mNodes.push_back(OctTreeNode()); return mNodes.size() - 1;}
};

